import discord
from discord.ext import commands
from model import get_class
from model2 import get_class2

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=discord.Intents.default())

@bot.command()
async def check(ctx):
    if ctx.message.attachments:
        for attachment in ctx.message.attachments:
            await attachment.save(f"./{attachment.filename}")
            await ctx.send(get_class(model_path="./keras_model.h5", labels_path="labels.txt", image_path=f"./{attachment.filename}"))
            await ctx.send(get_class2(model_path="./keras_model2.h5", labels_path="labels2.txt", image_path=f"./{attachment.filename}"))
    else:
        await ctx.send("Вы забыли загрузить картинку")

bot.run("MTE1NTUwMDI1ODMzMjI1MDIyMg.GrDSKi.26W3gzkwi1pU93CTljTAs-N6YcuOPZPWaxvdaY")